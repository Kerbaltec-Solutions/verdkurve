import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class verdkurve extends PApplet {

/*This work is licensed under the Creative Commons Attribution - Non-Commercial - Share Alike 4.0 International License. To view a copy of this license, visit
http://creativecommons.org/licenses/by-nc-sa/4.0/.*/

int x,y,px=100,py=50;
int max=255,min=0;
PImage cfrm = createImage(1000,300,RGB);
PImage cc;
int sizeA = 200;
int sizeB = 100;
int brigA = 255;
int brigB = 150;

public void setup(){
  
  background(0);
  textSize(20);
  adjust();
  drawScene();
  drawText();
  drawSliders();
  cc=loadImage("by-nc-sa.png");
  image(cc,width-285,height-99,285,99);
}
public void draw(){
  drawFrame(PApplet.parseFloat(frameCount)/100);
  cfrm=get(0,height-300,1000,300);
  drawGraph(brightness(cfrm));
}

public void adjust(){
  drawFrame(0);
  cfrm=get(0,height-300,1000,300);
  brightness(cfrm);
  max=ceil(brightness(cfrm));
  drawFrame(PI*1.5f);
  cfrm=get(0,height-300,1000,300);
  brightness(cfrm);
  min=floor(brightness(cfrm));
  drawFrame(PI*0.5f);
  cfrm=get(0,height-300,1000,300);
  brightness(cfrm);
  min=min(min,floor(brightness(cfrm)));
  println(min+"|"+max);
}

public void drawFrame(float n){
  stroke(255);
  fill(0);
  rect(0,height-300,999,299);
  noStroke();
  if(sin(n)<0){
    fill(brigA);
    circle(500,height-150,sizeA);
    fill(brigB);
    circle(500+cos(n)*400,height-150,sizeB);
  }else{
    fill(brigB);
    circle(500+cos(n)*400,height-150,sizeB);
    fill(brigA);
    circle(500,height-150,sizeA);
  }
}

public float brightness(PImage img){
  float bright;
  long pot=0;
  int count=0;
  for(int x=0; x<img.width; x++){
    for(int y=0; y<img.height; y++){
      pot+=brightness(img.pixels[x*y]);
      count++;
    }
  }
  bright=pot/PApplet.parseFloat(count);
  noStroke();
  fill(0);
  rect(1000,height-99,200,100);
  fill(map(bright,min,max,0,255));
  stroke(255);
  circle(1050,height-50,98);
  fill(bright);
  circle(1150,height-50,98);
  return bright;
}

public void drawScene(){
  stroke(100);
  for(float i=min;i<=max;i+=.5f){
    line(100,50+map(i,min,max,0,height-400),width-50,50+map(i,min,max,0,height-400));
  }
  for(int i=0; i<=360; i+=45){
    line(map(i,0,360,100,width-50),50,map(i,0,360,100,width-50),height-350);
  }
}

public void drawText(){
    fill(200);
  for(float i=min;i<=max;i+=.5f){
    textAlign(RIGHT);
    text(PApplet.parseInt(i*10),80,map(i,min,max,height-400,0)+55);
  }
  for(int i=0; i<=360; i+=45){
    textAlign(CENTER);
    text(i+"°",map(i,0,360,100,width-50),30);
  }
}

public void drawGraph(float brig){
  x=PApplet.parseInt(map(PApplet.parseFloat(frameCount)%(200*PI),0,200*PI,100,width-50));
  y=PApplet.parseInt(map(brig,min,max,height-400,0)+50);
  noStroke();
  fill(0,25);
  rect(x,50,100,height-400);
  drawScene();
  stroke(255);
  line(px,py,x,y);
  px=x;
  py=y;
  if(frameCount==PApplet.parseInt(200*PI)){
    frameCount=0;
    px=100;
    py=50;
  }
}

public void drawSliders(){
  stroke(255);
  fill(150);
  rect(1000,height-300,map(sizeA,0,200,0,width-1010),50);
  rect(1000,height-250,map(sizeB,0,200,0,width-1010),50);
  rect(1000,height-200,map(brigA,0,255,0,width-1010),50);
  rect(1000,height-150,map(brigB,0,255,0,width-1010),50);
  fill(0);
  rect(1000+map(sizeA,0,200,0,width-1010),height-300,width-1010-map(sizeA,0,200,0,width-1010),50);
  rect(1000+map(sizeB,0,200,0,width-1010),height-250,width-1010-map(sizeB,0,200,0,width-1010),50);
  rect(1000+map(brigA,0,255,0,width-1010),height-200,width-1010-map(brigA,0,255,0,width-1010),50);
  rect(1000+map(brigB,0,255,0,width-1010),height-150,width-1010-map(brigB,0,255,0,width-1010),50);
  fill(255);
  textAlign(LEFT);
  text("D1="+sizeA,1010,height-270);
  text("D2="+sizeB,1010,height-220);
  text("L1="+brigA,1010,height-170);
  text("L2="+brigB,1010,height-120);
}

public void mousePressed(){
  if(mouseX>1000){
    if(mouseY>height-300 && mouseY<height-200){
      if(mouseY<height-250){
        sizeA=PApplet.parseInt(map(mouseX,1000,width-10,0,200));
        if(sizeA>200)sizeA=200;
      }else{
        sizeB=PApplet.parseInt(map(mouseX,1000,width-10,0,200));
        if(sizeB>200)sizeB=200;
      }
    }else if(mouseY>height-200){
      if(mouseY<height-150){
        brigA=PApplet.parseInt(map(mouseX,1000,width-10,0,255));
        if(brigA>255)brigA=255;
      }else{
        brigB=PApplet.parseInt(map(mouseX,1000,width-10,0,255));
        if(brigB>255)brigB=255;
      }
    }
  }
  background(0);
  frameCount=0;
  px=100;
  py=50;
  adjust();
  drawScene();
  drawText();
  drawSliders();
  image(cc,width-285,height-99,285,99);
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "verdkurve" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
